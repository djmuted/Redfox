﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Redfox.Configs
{
    public class ZoneConfig
    {
        public string zone_name;
        public List<string> zone_extensions;
        public List<RoomConfig> zone_rooms;
    }
}
