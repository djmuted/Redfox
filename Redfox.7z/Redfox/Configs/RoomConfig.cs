﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Redfox.Configs
{
    public class RoomConfig
    {
        public string room_name;
        public int max_users = 100;
    }
}
