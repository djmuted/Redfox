﻿using System;
using System.Collections.Generic;
using System.Text;
using Redfox.Network.NetworkClients;

namespace Redfox.Network.NetworkServers
{
    interface INetworkServer
    {

    }
}
