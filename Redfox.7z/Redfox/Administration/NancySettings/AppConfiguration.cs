﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Redfox.Administration.NancySettings
{
    public class AppConfiguration : IAppConfiguration
    {
        
    }

}
